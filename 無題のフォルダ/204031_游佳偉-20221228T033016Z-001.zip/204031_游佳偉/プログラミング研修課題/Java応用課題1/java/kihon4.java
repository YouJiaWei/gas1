package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class kihon4 extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kihon4);
        //課題2
        Cat cat=new Cat("ミミ","ニャ",10,11);

        //String result = showMe(cat);
        //String result = sing(cat);
        //String result = sing(cat,3);
        //String result = eat(cat);
        //String result = hotel(cat);
        //String result = tired(cat);


        TextView tvResult = findViewById(R.id.result4);

        Button button37 = findViewById(R.id.button37);
        Button button38 = findViewById(R.id.button38);
        Button button39 = findViewById(R.id.button39);
        Button button40 = findViewById(R.id.button40);
        Button button41 = findViewById(R.id.button41);
        Button button42 = findViewById(R.id.button42);



        button37.setOnClickListener(v -> {
            String result = "";
            result = showMe(cat);
            tvResult.setText(result);
        });

        button38.setOnClickListener(v -> {
            String result = "";
            result = sing(cat);
            tvResult.setText(result);
        });

        button39.setOnClickListener(v -> {
            String result = "";
            result = sing(cat,3);
            tvResult.setText(result);
        });

        button40.setOnClickListener(v -> {
            String result = "";
            result = eat(cat);
            tvResult.setText(result);
        });

        button41.setOnClickListener(v -> {
            String result = "";
            result = hotel(cat);
            tvResult.setText(result);
        });

        button42.setOnClickListener(v -> {
            String result = "";
            result = tired(cat);
            tvResult.setText(result);
        });
    }

    //課題3
    private String showMe(Cat cat) {
        return cat.showMe();
    }
    //課題4
    private String sing(Cat cat) {
        return cat.sing();
    }
    //課題5
    private String sing(Cat cat,int n) {
        return cat.sing(n);
    }
    //課題6
    private String eat(Cat cat) {
        return cat.eat();
    }
    //課題7
    private String hotel(Cat cat) {
        return cat.hotel();
    }
    //課題8
    private String tired(Cat cat) {
        String resultStr= "";
        if(cat.tired()){
            resultStr= resultStr+"疲れたニャ\n";
        }else{
            resultStr= resultStr+"元気だニャ\n";
        }
        return resultStr;
    }


}