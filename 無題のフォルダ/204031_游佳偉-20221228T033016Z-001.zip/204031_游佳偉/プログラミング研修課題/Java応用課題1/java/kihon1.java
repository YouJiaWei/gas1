package com.systena.yuuk;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class kihon1 extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kihon1);

        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);
        Button button10 = findViewById(R.id.button10);
        Button button11 = findViewById(R.id.button11);
        Button button12 = findViewById(R.id.button12);

        TextView tvResult = findViewById(R.id.result1);

        button5.setOnClickListener(v -> {
            String result = "";
            result = callSubject01(2, 3);
            tvResult.setText(result);
        });

        button6.setOnClickListener(v -> {
            String result = "";
            result = callSubject02(Integer.MAX_VALUE, Integer.MIN_VALUE);
            tvResult.setText(result);
        });

        button7.setOnClickListener(v -> {
            String result = "";
            result = callSubject03(183);
            tvResult.setText(result);
        });

        button8.setOnClickListener(v -> {
            String result = "";
            result = callSubject04(183, 95);
            tvResult.setText(result);
        });

        button9.setOnClickListener(v -> {
            String result = "";
            result = callSubject05(1234);
            tvResult.setText(result);
        });

        button10.setOnClickListener(v -> {
            String result = "";
            result = callSubject06(58);
            tvResult.setText(result);
        });

        button11.setOnClickListener(v -> {
            String result = "";
            result = callSubject07(9,10,12,20);
            tvResult.setText(result);
        });

        button12.setOnClickListener(v -> {
            String result = "";
            result = callSubject08(2, 2, 57);
            tvResult.setText(result);
        });



    }
    //課題1
    private String callSubject01(final int a,final int b){
        String resultStr = "aは"+a+"\n"
                + "bは"+b+"\n"
                + "aとbを足すと"+(a+b);
        return resultStr;
    }
    //課題2
    private String callSubject02(final int max,final int min){
        //int max=2147483647;
        //int min=-2147483648;
        int x=max+5;
        int y =min-7;
        String resultStr = max+"に5を足すと"+x+"\n"
                +min+"から7を引くと"+y;
        return resultStr;
    }
    //課題3
    private String callSubject03(final int height) {
        double weight = (height - 100) * 0.9;
        String resultStr = "身長" + height + "cmの人の標準体重は" + weight + "です";
        return resultStr;
    }
    //課題4
    private String callSubject04(final int height,final int weight) {
        double x=(double)height/100;
        double BMI = weight/x/x;

        String resultStr = "身長" + height + "cm、体重" + weight + "kgの人のBMI指数は\n"
                +BMI+"です";
        return resultStr;
    }
    //課題5
    private String callSubject05(final int price) {
        //int x=(int)price-(int)(price*0.3);
        int x=(int)(price*0.7);

        String resultStr = "定価" + price + "円の3割引後の価格は" + x + "円です";
        return resultStr;
    }
    //課題6
    private String callSubject06(final int x) {

        int m= x%10;
        int n= x/10;
        int l=m*10+n;

        String resultStr = x+"の反対は" + l + "です";
        return resultStr;
    }
    //課題7
    private String callSubject07(final int t1,final int t2, final int t3,final int t4) {

        int hour1 = t1 * 60 + t2;
        int hour2 = t3 * 60 + t4;
        int resulthour = (hour2-hour1)/60;
        int resultmin  = (hour2-hour1)%60;

        String resultStr = t1+"時" + t2 + "分から"+t3+"時"+t4+"分までは\n"
                +resulthour+"時間"+resultmin+"分です";
        return resultStr;
    }
    //課題8
    private String callSubject08(final int t1,final int t2, final int t3) {

        int hour1 = t1 * 3600 + t2*60 + t3;
        double long1= 42195;
        double speed =(hour1/long1);
        double speed1=100*speed;

        String resultStr = "デニス・キプルト・キメット選手の100mの平均タイムは\n"
                +speed1+"秒です";
        return resultStr;
    }
}