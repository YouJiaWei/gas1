package com.systena.yuuk;

public class Cat {
    String name;
    String song;
    int power;
    int money;


    public Cat(String name, String song, int power, int money){
        this.name=name;
        this.song=song;
        this.power=power;
        this.money=money;
    }

    //課題3
    public String showMe(){
        String resultStr= "私は"+this.name+"、"+this.song+"と鳴きます。\n"+
                "パワーは"+this.power+"、"+this.money+"円持っています。\n";
        return resultStr;
    }

    //課題4
    public String sing(){
        String resultStr= "ニャ";
        return resultStr;
    }
    //課題5
    public String sing(int n){
        String resultStr= "";
        for(int i=1;i<=n;i=i+1){
            resultStr= resultStr+"ニャ";
        }
        resultStr= resultStr +" (n=" +n+"の場合)";
        return resultStr;
    }
    //課題6
    public String eat(){
        String resultStr= "";
        if(this.money>=1){
            resultStr= resultStr+"おいしかった\n";
            this.money-=1;
            this.power+=10;
        }else{
            resultStr= resultStr+"お金が足りない\n";
        }
        return resultStr;
    }
    //課題7
    public String hotel(){
        String resultStr= "";
        if(this.money>=10){
            resultStr= resultStr+"あーよく寝た\n";
            this.money-=10;
            this.power+=20;
        }else{
            resultStr= resultStr+"野宿はつらい\n";
        }
        return resultStr;
    }
    //課題8
    public boolean tired(){
        if(this.money<0 && this.power<0){
            return true;
        }else{
            return false;
        }
    }



}
