package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class kihon2 extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kihon2);

        Button button13 = findViewById(R.id.button13);
        Button button14 = findViewById(R.id.button14);
        Button button15 = findViewById(R.id.button15);
        Button button16 = findViewById(R.id.button16);
        Button button17 = findViewById(R.id.button17);
        Button button18 = findViewById(R.id.button18);
        Button button19 = findViewById(R.id.button19);
        Button button20 = findViewById(R.id.button20);
        Button button21 = findViewById(R.id.button21);
        Button button22 = findViewById(R.id.button22);

        //String result = callSubject02_1(20);
        //String result = callSubject02_2(15);
        //String result = callSubject02_3(90);
        //String result = callSubject02_4(12);
        //String result = callSubject02_5(11);
        //String result = callSubject02_6(30);
        //String result = callSubject02_7(15);
        //String result = callSubject02_8(70);
        //String result = callSubject02_9(10);
        //String result = callSubject02_10(10);

        TextView tvResult = findViewById(R.id.result2);

        button13.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_1(20);;
            tvResult.setText(result);
        });

        button14.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_1(15);
            tvResult.setText(result);
        });

        button15.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_3(90);
            tvResult.setText(result);
        });

        button16.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_4(12);
            tvResult.setText(result);
        });

        button17.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_5(11);
            tvResult.setText(result);
        });

        button18.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_6(30);
            tvResult.setText(result);
        });

        button19.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_7(15);
            tvResult.setText(result);
        });

        button20.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_8(70);
            tvResult.setText(result);
        });

        button21.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_9(7);
            tvResult.setText(result);
        });

        button22.setOnClickListener(v -> {
            String result = "";
            result = callSubject02_10(10);
            tvResult.setText(result);
        });


    }
    //課題1
    private String callSubject02_1(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>=18){
            resultStr= resultStr+"どうぞ\n";
        }
            resultStr = resultStr+"おしまい";
        return resultStr;
    }
    //課題2
    private String callSubject02_2(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>=18){
            resultStr= resultStr
                    +"どうぞ\n";
        }
        else{
            resultStr = resultStr
                    +"お断り\n";
        }
        resultStr = resultStr+"おしまい";
        return resultStr;
    }
    //課題3
    private String callSubject02_3(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age<18){
            resultStr = resultStr
                    +"お断り\n";
        }
        else if(age>=18 && age<80){
            resultStr= resultStr
                    +"どうぞ\n";
        }
        else if(age>=80){
            resultStr = resultStr
                    +"どうぞどうぞ\n";
        }
        resultStr = resultStr+"おしまい";
        return resultStr;
    }
    //課題4
    private String callSubject02_4(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a%3==0 && a%5==0){
            resultStr = resultStr
                    +a+"は3でも5でも割り切れます。\n";
        }

        return resultStr;
    }
    //課題5
    private String callSubject02_5(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a%3==0 || a%5==0){
            resultStr = resultStr
                    +a+"は、3か5で割り切れます。\n";
        }
        else{
            resultStr = resultStr
                    +a+"は、3でも5でも割り切れません。\n";
        }

        return resultStr;
    }
    //課題6
    private String callSubject02_6(final int a){
        String resultStr= "2桁の整数値は"+a+"\n";
        if(a/10==3 || a%10==3){
            resultStr = resultStr
                    +a+"に3が含まれます。\n";
        }
        else{
            resultStr = resultStr
                    +a+"に3は含まれません。\n";
        }

        return resultStr;
    }
    //課題7
    private String callSubject02_7(final int a){
        String resultStr= "2桁の整数値は"+a+"\n";
        if(a/10==3 || a%10==3 || a%3==0){
            resultStr = resultStr
                    +a+" ナベアツ ";
            }
        if(a%5==0){
            resultStr = resultStr
                    +" 犬";
        }

        return resultStr;
    }
    //課題8
    private String callSubject02_8(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>12 && age<70){
            resultStr = resultStr
                    +"1000円";
        }
        else{
            resultStr = resultStr
                    +"ただ";
        }

        return resultStr;
    }
    //課題9
    private String callSubject02_9(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a==7){
            resultStr = resultStr
                    +"ハッピー";
        }
        else if(a==3){
            resultStr = resultStr
                    +"ラッキー";
        }
        else if(a==13){
            resultStr = resultStr
                    +"アンラッキー";
        }
        else{
            resultStr = resultStr
                    +"普通";
        }

        return resultStr;
    }
    //課題10
    private String callSubject02_10(final int a){
        String resultStr= "整数値は"+a+"\n";
        switch (a){
            case 7:
            resultStr = resultStr
                    +"ハッピー";
            break;
            case 3:
            resultStr = resultStr
                    +"ラッキー";
            break;
            case 13:
            resultStr = resultStr
                    +"アンラッキー";
            break;
            default:
            resultStr = resultStr
                    +"普通";
        }

        return resultStr;
    }

}
