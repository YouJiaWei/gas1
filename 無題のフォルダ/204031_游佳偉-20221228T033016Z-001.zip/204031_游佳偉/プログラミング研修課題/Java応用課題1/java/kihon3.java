package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class kihon3 extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kihon3);

        //String result = callSubject03_1(6);
        //String result = callSubject03_2(2);
        //String result = callSubject03_3(30);
        //String result = callSubject03_4(10);
        //String result = callSubject03_5(10);
        //String result = callSubject03_6(5);
        //String result = callSubject03_7(9);
        //String result = callSubject03_8(-5);
        //String result = callSubject03_9(10);
        //String result = callSubject03_10(30);
        //String result = callSubject03_11(5);
        //String result = callSubject03_12(5);
        //String result = callSubject03_13(5);
        //String result = callSubject03_14(5);

        TextView tvResult = findViewById(R.id.result3);
        //tvResult.setText(result);
        Button button23 = findViewById(R.id.button23);
        Button button24 = findViewById(R.id.button24);
        Button button25 = findViewById(R.id.button25);
        Button button26 = findViewById(R.id.button26);
        Button button27 = findViewById(R.id.button27);
        Button button28 = findViewById(R.id.button28);
        Button button29 = findViewById(R.id.button29);
        Button button30 = findViewById(R.id.button30);
        Button button31 = findViewById(R.id.button31);
        Button button32 = findViewById(R.id.button32);
        Button button33 = findViewById(R.id.button33);
        Button button34 = findViewById(R.id.button34);
        Button button35 = findViewById(R.id.button35);
        Button button36 = findViewById(R.id.button36);

        button23.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_1(6);
            tvResult.setText(result);
        });

        button24.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_2(2);
            tvResult.setText(result);
        });

        button25.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_3(30);
            tvResult.setText(result);
        });

        button26.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_4(10);
            tvResult.setText(result);
        });

        button27.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_5(10);
            tvResult.setText(result);
        });

        button28.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_6(5);
            tvResult.setText(result);
        });

        button29.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_7(9);
            tvResult.setText(result);
        });

        button30.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_8(-5);
            tvResult.setText(result);
        });

        button31.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_9(10);
            tvResult.setText(result);
        });

        button32.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_10(30);
            tvResult.setText(result);
        });

        button33.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_11(5);
            tvResult.setText(result);
        });

        button34.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_12(5);
            tvResult.setText(result);
        });

        button35.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_13(5);
            tvResult.setText(result);
        });

        button36.setOnClickListener(v -> {
            String result = "";
            result = callSubject03_14(5);
            tvResult.setText(result);
        });


    }
    //課題1
    private String callSubject03_1(final int a){
        String resultStr= "";
        for(int i=0;i<=a;i=i+2){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }
    //課題2
    private String callSubject03_2(final int a){
        String resultStr= "";
        for(int i=5;i>=a;i=i-1){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }
    //課題3
    private String callSubject03_3(final int a){
        String resultStr= "";
        for(int i=-10;i<=a;i=i+5){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }
    //課題4
    private String callSubject03_4(final int a){
        String resultStr= "";
        for(int i=1;i<=a;i=i+1){
            resultStr= resultStr+(i*i)+"\n";
        }
        return resultStr;
    }
    //課題5
    private String callSubject03_5(final int a){
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            resultStr = resultStr + i +" "+  (10-i) + "\n";
        }
        return resultStr;
    }
    //課題6
    private String callSubject03_6(final int a){
        int n=1;
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            n=n+i;
            resultStr = resultStr + n + "\n";
        }
        return resultStr;
    }
    //課題7
    private String callSubject03_7(final int a){
        int n=1;
        int k=0;
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            n=n+k;
            resultStr = resultStr + n + "\n";
            k=n-k;
        }
        return resultStr;
    }
    //課題8
    private String callSubject03_8(final int a){
        int n=0;
        String resultStr= "";
        for(int i=1;i<=a;i=i+1) {
            n=n+i;
        }
        resultStr = resultStr +"1から" +a+"までの合計は"+n + "\n";
        return resultStr;
    }
    //課題9
    private String callSubject03_9(final int a){
        int n=0;
        int i;
        String resultStr= "";
        if(a>0){
            for(i=1;i<a;i=i+1) {
                n=n+i;
                resultStr = resultStr +i+"+";
            }
            n=n+i;
            resultStr = resultStr +i+"="+n;
        }
        else{
            resultStr = resultStr +"?";
        }

        return resultStr;
    }
    //課題10
    private String callSubject03_10(final int a){
        long n=1;
        int i;
        String resultStr= "";
            for(i=1;i<=a;i=i+1) {
                resultStr = resultStr +i+"回目は"+n+"円\n";
                n=n*2;
            }

        return resultStr;
    }
    //課題11
    private String callSubject03_11(final int a){
        int i;
        int j;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            for(j=0;j<a;j++) {
                resultStr = resultStr + "＊";
            }
            resultStr = resultStr +"\n";
        }
        //resultStr = resultStr +"\n";
        return resultStr;
    }
    //課題12
    private String callSubject03_12(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            if(i%2==0) {
                for (j = 0; j < 5; j++) {
                    resultStr = resultStr + "＊";
                }
            }else{
                for (k = 0; k < 5; k = k + 1) {
                    resultStr = resultStr + "＋";
                }
            }
            resultStr = resultStr +"\n";
        }
        return resultStr;
    }
    //課題13
    private String callSubject03_13(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
                for (j = 0; j < i+1; j++) {
                    resultStr = resultStr + "＊";
                }
            resultStr = resultStr +"\n";
            }
        return resultStr;
    }
    //課題14
    private String callSubject03_14(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            for (j = 5; j > i; j--) {
                resultStr = resultStr + "＊";
            }
            resultStr = resultStr +"\n";
        }
        return resultStr;
    }

}