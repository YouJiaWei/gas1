package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String result = callSubject08(2,2,57);
        TextView tvResult = findViewById(R.id.tv_result);
        tvResult.setText(result);
    }
    private String callSubject01(final int a,final int b){
        String resultStr = "aは"+a+"\n"
                + "bは"+b+"\n"
                + "aとbを足すと"+(a+b);
        return resultStr;
    }
    private String callSubject02(final int max,final int min){
        //int max=2147483647;
        //int min=-2147483648;
        int x=max+5;
        int y =min-7;
        String resultStr = max+"に5を足すと"+x+"\n"
                +min+"から7を引くと"+y;
        return resultStr;
    }

    private String callSubject03(final int height) {
        double weight = (height - 100) * 0.9;
        String resultStr = "身長" + height + "cmの人の平準体重は" + weight + "です";
        return resultStr;
    }

    private String callSubject04(final int height,final int weight) {
        double x=(double)height/100;
        double BMI = weight/x/x;

        String resultStr = "身長" + height + "cm、体重" + weight + "kgの人のBMI指数は\n"
                +BMI+"です";
        return resultStr;
    }

    private String callSubject05(final int price) {
        //int x=(int)price-(int)(price*0.3);
        int x=(int)(price*0.7);

        String resultStr = "定価" + price + "円の3割引後の価格は" + x + "円です";
        return resultStr;
    }

    private String callSubject06(final int x) {

        int m= x%10;
        int n= x/10;
        int l=m*10+n;

        String resultStr = x+"の反対は" + l + "です";
        return resultStr;
    }

    private String callSubject07(final int t1,final int t2, final int t3,final int t4) {

         int hour1 = t1 * 60 + t2;
         int hour2 = t3 * 60 + t4;
         int resulthour = (hour2-hour1)/60;
         int resultmin  = (hour2-hour1)%60;

        String resultStr = t1+"時" + t2 + "分から"+t3+"時"+t4+"分までは\n"
                +resulthour+"時間"+resultmin+"分です";
        return resultStr;
    }

    private String callSubject08(final int t1,final int t2, final int t3) {

        int hour1 = t1 * 3600 + t2*60 + t3;
        double long1= 42195;
        double speed =(hour1/long1);
        double speed1=100*speed;

        String resultStr = "デニス・キプルト・キメット選手の100mの平均タイムは\n"
                +speed1+"秒です";
        return resultStr;
    }


}