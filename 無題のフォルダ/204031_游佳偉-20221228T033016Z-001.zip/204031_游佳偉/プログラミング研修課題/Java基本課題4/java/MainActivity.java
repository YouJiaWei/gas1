package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //課題2
        Cat cat=new Cat("ミミ","ニャ",10,11);

        //String result = showMe(cat);
        //String result = sing(cat);
        //String result = sing(cat,3);
        //String result = eat(cat);
        //String result = hotel(cat);
        String result = tired(cat);


        TextView tvResult = findViewById(R.id.tv_result);
        tvResult.setText(result);
    }

    //課題3
    private String showMe(Cat cat) {
        return cat.showMe();
    }
    //課題4
    private String sing(Cat cat) {
        return cat.sing();
    }
    //課題5
    private String sing(Cat cat,int n) {
        return cat.sing(n);
    }
    //課題6
    private String eat(Cat cat) {
        return cat.eat();
    }
    //課題7
    private String hotel(Cat cat) {
        return cat.hotel();
    }
    //課題8
    private String tired(Cat cat) {
        String resultStr= "";
        if(cat.tired()){
            resultStr= resultStr+"疲れたニャ\n";
        }else{
            resultStr= resultStr+"元気だニャ\n";
        }
        return resultStr;
    }


}