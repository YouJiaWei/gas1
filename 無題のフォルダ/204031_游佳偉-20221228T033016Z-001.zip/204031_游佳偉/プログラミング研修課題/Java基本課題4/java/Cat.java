package com.systena.yuuk;

public class Cat {
    String name;
    String song;
    int power;
    int money;


    public Cat(String name, String song, int power, int money){
        this.name=name;
        this.song=song;
        this.power=power;
        this.money=money;
    }


    public String showMe(){
        String resultStr= "私は"+this.name+"、"+this.song+"と鳴きます。\n"+
                "パワーは"+this.power+"、"+this.money+"円持っています。\n";
        return resultStr;
    }


    public String sing(){
        String resultStr= "ニャ";
        return resultStr;
    }

    public String sing(int n){
        String resultStr= "";
        for(int i=1;i<=n;i=i+1){
            resultStr= resultStr+"ニャ";
        }
        resultStr= resultStr +" (n=" +n+"の場合)";
        return resultStr;
    }

    public String eat(){
        String resultStr= "";
        if(this.money>=1){
            resultStr= resultStr+"おいしかった\n";
            this.money-=1;
            this.power+=10;
        }else{
            resultStr= resultStr+"お金が足りない\n";
        }
        return resultStr;
    }

    public String hotel(){
        String resultStr= "";
        if(this.money>=10){
            resultStr= resultStr+"あーよく寝た\n";
            this.money-=10;
            this.power+=20;
        }else{
            resultStr= resultStr+"野宿はつらい\n";
        }
        return resultStr;
    }

    public boolean tired(){
        if(this.money<0 && this.power<0){
            return true;
        }else{
            return false;
        }
    }



}
