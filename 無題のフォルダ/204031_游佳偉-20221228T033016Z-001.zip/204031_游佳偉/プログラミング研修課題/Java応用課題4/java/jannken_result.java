package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.widget.ImageButton;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.AlertDialog;
import android.view.View.OnClickListener;

import java.util.Random;


public class jannken_result extends jannken {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jannken_result);

        Intent intent = getIntent();
        Intent intent1 = new Intent(getApplication(),jannken.class);

        TextView jannken_result = findViewById(R.id.jannken_result);

        //相手のデータ
        Random random = new Random();
        int opposite_data = random.nextInt(3);

        //ボタンとメッセージの設定
        Button button_more = findViewById(R.id.button_more);

        TextView myname = (TextView)findViewById(R.id.myname);
        TextView myhand = (TextView)findViewById(R.id.myhand);
        TextView ophand = (TextView)findViewById(R.id.ophand);

        TextView name_2 = findViewById(R.id.name_2);

        //名前を取る
        String name=intent.getStringExtra("MyName");

        //自分のデータ
        int myhand_data = intent.getIntExtra("MyHand",0);

        //勝敗履歴のデータ
        int win = intent.getIntExtra("Win",0);
        int lose = intent.getIntExtra("Lose",0);
        int draw = intent.getIntExtra("Draw",0);

        //名前を表示
        name_2.setText(name);
        myname.setText(name);

        //自分の手
        if (myhand_data==0){
            myhand.setText("グー");
        }else if(myhand_data==1){
            myhand.setText("チョキ");
        }else{
            myhand.setText("パー");
        }

        //相手の手
        if (opposite_data==0){
            ophand.setText("グー");
        }else if(opposite_data==1){
            ophand.setText("チョキ");
        }else{
            ophand.setText("パー");
        }

        //判定
        int final_data = opposite_data - myhand_data;
        if (opposite_data==myhand_data){
            jannken_result.setText("あいこです");
            draw = draw+1;
        }else if(final_data==-1 || final_data +3 ==-1 || final_data-3==-1){
            jannken_result.setText(name + "さんの負けです");
            lose = lose+1;
        }else{
            jannken_result.setText(name + "さんの勝ちです");
            win = win+1;
        }


        int Win_data = win;
        int Lose_data = lose;
        int Draw_data = draw;
        //もう一回
        button_more.setOnClickListener(v -> {
            intent1.putExtra("MyName",name);
            intent1.putExtra("Win", Win_data);
            intent1.putExtra("Lose", Lose_data);
            intent1.putExtra("Draw", Draw_data);
            startActivity(intent1);

        });


    }







}
