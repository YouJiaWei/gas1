package com.systena.yuuk;

import java.util.Random;

public class CatExt {
    String name;
    String song;
    int power;
    int money;


    public CatExt(String name, String song, int power, int money){
        this.name=name;
        this.song=song;
        this.power=power;
        this.money=money;
    }

    //課題3
    public String showMe(){
        String resultStr= "私は"+this.name+"、"+this.song+"と鳴きます。\n"+
                "パワーは"+this.power+"、"+this.money+"円持っています。\n";
        return resultStr;
    }

    //課題4
    public String sing(){
        String resultStr= "ニャ";
        return resultStr;
    }
    //課題5
    public String sing(int n){
        String resultStr= "";
        for(int i=1;i<=n;i=i+1){
            resultStr= resultStr+"ニャ";
        }
        return resultStr;
    }
    //課題6
    public String eat(){
        String resultStr= "";
        if(this.money>=1){
            this.money-=1;
            this.power+=10;
            resultStr= resultStr+"おいしかった\nパワーが" + this.power + "になった！\nお金が" +
                    this.money + "円になった";
        }else{
            resultStr= resultStr+"お金が足りない\n今のお金が" + this.money + "円";
        }
        return resultStr;
    }
    //課題7
    public String hotel(int n){
        String resultStr= "";
        int i;
        if(n!=0) {
            if(this.money>=10*n) {
                for (i = 1; i <= n; i = i + 1) {
                    this.money-=10;
                    this.power+=20;
                    resultStr=resultStr+"あーよく寝た\n";
                }
                resultStr= resultStr+n+"泊泊まる。\n パワーが" + this.power + "になった！\nお金が"
                        + this.money + "円になった";
                }
            else {
                resultStr= n+"泊するにはお金が足りません\n野宿はつらい\n"
                +"今のお金が" + this.money + "円";
            }
        }
        return resultStr;
    }
    //課題8
    public boolean tired(){
        if(this.money<=0 && this.power<=0){
            return true;
        }else{
            return false;
        }
    }

    public String janken() {
        String janken = "";
        String my = "";
        String oppo = "";
        Random rand = new Random();
        int myhand = rand.nextInt(3);
        int opposite = rand.nextInt(3);

        int result_jannken;

        if (myhand == 0) {
            my = "グー";
        } else if (myhand == 1) {
            my = "チョキ";
        } else if (myhand == 2) {
            my = "パー";
        }

        if (opposite == 0) {
            oppo = "グー";
        } else if (opposite == 1) {
            oppo = "チョキ";
        } else if (opposite == 2) {
            oppo = "パー";
        }


        result_jannken = myhand - opposite ;

        if (this.money >= 10) {
            if (result_jannken == 0) {
                janken = "あなたは" + my + "を出しました" + "\n"
                        + "相手は" + oppo + "を出しました" + "\n"
                        +"あいこです";

            } else if (result_jannken == -1 || result_jannken + 3 == -1 || result_jannken - 3 == -1) {
                janken = "あなたは" + my + "を出しました" + "\n"
                        + "相手は" + oppo + "を出しました" + "\n"
                        + "あなたの勝ちです" + "\n"
                        + "10円もらいました";
                this.money = this.money + 10;

            } else {
                janken = "あなたは" + my + "を出しました" + "\n"
                        + "相手は" + oppo + "を出しました" + "\n"
                        + "あなたの負けです" + "\n"
                        + "10円失いました";
                this.money = this.money - 10;
            }
        } else {
            janken = "じゃんけんには10円以上のお金が必要です";
        }
        return janken;
    }

    public String work() {
        String work = "";
        if (this.power > 0) {
            this.power--;
            this.money = this.money + 10;
            work = "パワーを1失った。お金を10円もらった";
        } else {
            this.money = this.money + 1;
            work = "お金を1円もらった";
        }
        return work;
    }

    String fight(CatExt other) {
        String fight = "";
        if (this.power > 0) {
            if (this.power > other.power) {
                fight = "今、あなたのパワーは"+this.power+"お金は"+this.money+"\n相手のパワーは"+other.power
                +"お金は"+other.money+"\n勝ちました!";
                this.power--;
                this.money = this.money + (other.money / 2);
            } else if (this.power == other.power) {
                fight = "今、あなたのパワーは"+this.power+"\n相手のパワーは"+other.power+
                        "\nあいこです!";
                this.power--;
            } else  {
                fight = "今、あなたのパワーは"+this.power+"お金は"+this.money+"\n相手のパワーは"+other.power
                        +"お金は"+other.money+"\n負けました!";
                this.power--;
                this.money = this.money - (this.money / 2);
            }
        } else{
                fight = "パワーはないので、お金をすべて失った";
            this.money = 0;
            }
        return fight;
    }
}