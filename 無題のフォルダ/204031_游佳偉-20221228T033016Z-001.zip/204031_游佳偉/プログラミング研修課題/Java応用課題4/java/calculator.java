package com.systena.yuuk;

import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class calculator extends MainActivity {


    private int firstNum = 0;
    private int secondNum = 0;
    private int thirdNum = 0;
    private int firstOperator = 0;
    private int secondOperator = 0;
    private boolean isPushEqual = false;
    private boolean isPushoppo = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);


        /*Button button_1 = findViewById(R.id.button_1);
        Button button_2 = findViewById(R.id.button_2);
        Button button_3 = findViewById(R.id.button_3);
        Button button_4 = findViewById(R.id.button_4);
        Button button_5 = findViewById(R.id.button_5);
        Button button_6 = findViewById(R.id.button_6);
        Button button_7 = findViewById(R.id.button_7);
        Button button_8 = findViewById(R.id.button_8);
        Button button_9 = findViewById(R.id.button_9);
        Button button_0 = findViewById(R.id.button_0);
        Button button_plus = findViewById(R.id.button_plus);
        Button button_minus = findViewById(R.id.button_minus);
        Button button_mul = findViewById(R.id.button_mul);
        Button button_div = findViewById(R.id.button_div);
        Button button_equal = findViewById(R.id.button_equal);
        Button button_oppo = findViewById(R.id.button_oppo);
        Button button_clear = findViewById(R.id.button_clear);*/

        findViewById(R.id.button_1).setOnClickListener(number_Listener);
        findViewById(R.id.button_2).setOnClickListener(number_Listener);
        findViewById(R.id.button_3).setOnClickListener(number_Listener);
        findViewById(R.id.button_4).setOnClickListener(number_Listener);
        findViewById(R.id.button_5).setOnClickListener(number_Listener);
        findViewById(R.id.button_6).setOnClickListener(number_Listener);
        findViewById(R.id.button_7).setOnClickListener(number_Listener);
        findViewById(R.id.button_8).setOnClickListener(number_Listener);
        findViewById(R.id.button_9).setOnClickListener(number_Listener);
        findViewById(R.id.button_0).setOnClickListener(number_Listener);
        findViewById(R.id.button_plus).setOnClickListener(Operator_Listener);
        findViewById(R.id.button_minus).setOnClickListener(Operator_Listener);
        findViewById(R.id.button_mul).setOnClickListener(Operator_Listener);
        findViewById(R.id.button_div).setOnClickListener(Operator_Listener);
        findViewById(R.id.button_oppo).setOnClickListener(oppo_Listener);
        findViewById(R.id.button_equal).setOnClickListener(Equal_Listener);
        findViewById(R.id.button_clear).setOnClickListener(Clear_Listener);

    }
    //数字ボタン
    View.OnClickListener number_Listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Button numberButton = (Button)view;
            TextView result_message = findViewById(R.id.result_message);

            //イコールボタンが押された直後なら表示をリセットする
            if(isPushEqual) {
                firstNum = 0;
                Clear();
            }

            if(result_message.getText().toString() == "ERROR") {
                result_message.setText("");
            }

            String result_messageStr = addNum(numberButton.getText().toString());

            //addNum()の結果がエラーでなければ表示
            if(result_message.getText().toString() != "ERROR") {
                result_message.setText(result_messageStr);
            }
        }
    };

    //クレアする
    private void Clear() {
        TextView input_message = findViewById(R.id.input_message);

        secondNum = 0;
        thirdNum = 0;
        firstOperator = 0;
        secondOperator = 0;
        isPushEqual = false;
        isPushoppo = false;

        input_message.setText("");
    }

    //入力された数字を元の数字の下の位に加える
    private String addNum(String numberStr) {
        int num = Integer.parseInt(numberStr);
        String resultStr = "";

        //あらかじめ＋/ーボタンが押されていたら、負の数を入力する
        if(isPushoppo) {
            num = 0 - num;
            isPushoppo = false;
        }

        if(firstOperator == 0) {
            if((firstNum == 214748364 && num > 7) || (firstNum == -214748364 && num > 8) ||
                    firstNum > 214748364 || firstNum < -214748364) {
                errorProcessing(); //エラー
            } else {
                if(firstNum < 0) {
                    num = 0 - num;
                }
                firstNum = firstNum * 10 +num; //元の数字を10倍して、入力された数字を一の位に入れる
            }

            resultStr =  Integer.toString(firstNum);

        } else if(secondOperator == 0) {
            if((secondNum == 214748364 && num > 7) || (secondNum == -214748364 && num > 8) ||
                    secondNum > 214748364 || secondNum < -214748364) {
                errorProcessing(); //エラー
            } else {
                if(secondNum < 0) {
                    num = 0 - num;
                }
                secondNum = secondNum * 10 + num;
            }

            resultStr = Integer.toString(secondNum);

        } else {
            if((thirdNum == 214748364 && num > 7) || (thirdNum == -214748364 && num > 8) ||
                    thirdNum > 214748364 || thirdNum < -214748364) {
                errorProcessing(); //エラー
            } else {
                if(thirdNum < 0) {
                    num = 0 - num;
                }
                thirdNum = thirdNum * 10 + num;
            }

            resultStr = Integer.toString(thirdNum);
        }

        return resultStr;
    }

    //エラー処理
    private void errorProcessing() {
        TextView input_message = findViewById(R.id.input_message);
        TextView result_message = findViewById(R.id.result_message);

        firstNum = 0;
        Clear();

        input_message.setText("");
        result_message.setText("ERROR");
    }

    //＋/ーボタンが押されたとき
    View.OnClickListener oppo_Listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            TextView result_message = findViewById(R.id.result_message);

            //イコールボタンが押された直後なら表示をリセットする
            if(isPushEqual) {
                firstNum = 0;
                Clear();
           }

            if(firstOperator == 0) {
                firstNum = plusMinusSwitch(firstNum);
                if(isPushoppo) {
                    result_message.setText("-0");
                } else {
                    result_message.setText(Integer.toString(firstNum));
                }
            } else if(secondOperator == 0) {
                secondNum = plusMinusSwitch(secondNum);
                if(isPushoppo) {
                    result_message.setText("-0");
                } else {
                    result_message.setText(Integer.toString(secondNum));
                }
            } else {
                thirdNum = plusMinusSwitch(thirdNum);
                if(isPushoppo) {
                    result_message.setText("-0");
                } else {
                    result_message.setText(Integer.toString(thirdNum));
                }
            }
        }

    };

    //＋/ーを反転させる
    private int plusMinusSwitch(int num) {
        int switchNum = 0 - num;

        if(switchNum == 0) {
            if(isPushoppo) {
                isPushoppo = false;
            } else {
                isPushoppo = true;
            }
        }

        return switchNum;
    }

    //演算子ボタンが押されたとき
    View.OnClickListener Operator_Listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Button operatorButton = (Button)view;
            TextView result_message = findViewById(R.id.result_message);

            //イコールボタンが押された直後なら表示をリセットする
            if(isPushEqual) {
                Clear();
            }

            if(result_message.getText().toString() == "ERROR") {
                result_message.setText("0");
            }
            String result_messageStr = result_message.getText().toString();

            calcFormula(operatorButton.getId(), Integer.parseInt(result_messageStr));
        }
    };

    //演算子の優先順位をつけて計算する
    private void calcFormula(int operatorId, int result_messageNumber) {
        int newOperator = toIntOperator(operatorId);
        String operatorStr = toStringOperator(newOperator);

        if(firstOperator == 0) {
            firstOperator = newOperator;
        } else if(secondOperator == 0) {
            //数字が何も入力されていない場合はfirstNumと同じになる
            secondNum = result_messageNumber;

            if(3 > firstOperator && newOperator >= 3) {
                //最初の演算子が＋/ーかつ2番目の演算子が×/÷の場合
                secondOperator = newOperator;
            } else { //それ以外
                firstNum = calculation(firstNum, secondNum, firstOperator);
                secondNum = 0;
                firstOperator = newOperator;
            }
        } else {
            //数字が何も入力されていない場合はsecondNumと同じになる
            thirdNum = result_messageNumber;
            secondNum = calculation(secondNum, thirdNum, secondOperator);

            if(newOperator >= 3) {
                //最初の演算子が＋/ーかつ新しい演算子が×/÷の場合
                secondOperator = newOperator;
            } else { //それ以外
                firstNum = calculation(firstNum, secondNum, firstOperator);
                secondNum = 0;
                secondOperator = 0;
                firstOperator = newOperator;
            }
            thirdNum = 0;
        }

        formulaDisplay(operatorStr);
    }

    //演算子を数値にして返す
    private int toIntOperator(int operatorId) {
        switch(operatorId) {
            case R.id.button_plus:
                return 1;
            case R.id.button_minus:
                return 2;
            case R.id.button_mul:
                return 3;
            case R.id.button_div:
                return 4;
            default:
                return 0;
        }
    }

    //演算子をString型にする
    private String toStringOperator(int operator) {
        switch(operator) {
            case 1:
                return "＋";
            case 2:
                return "ー";
            case 3:
                return "×";
            case 4:
                return "÷";
            default:
                return "";
        }
    }

    //二つの数で計算する
    private int calculation(int num_1, int num_2, int operator) {
        int result = 0;

        if(operator == 1) {
            //加算
            if(((num_2 >= 0) && num_1 > (2147483647 - num_2)) ||
                    ((num_2 < 0) && (-2147483648 - num_2) > num_1)) {
                errorProcessing(); //エラー
            } else {
                result = num_1 + num_2;
            }
        } else if(operator == 2) {
            //減算
            if(((num_2 >= 0) && (-2147483648 + num_2) > num_1) ||
                    ((num_2 < 0) && num_1 > (2147483647 + num_2))) {
                errorProcessing(); //エラー
            } else {
                result = num_1 - num_2;
            }
        } else if(operator == 3) {
            //乗算
            if(num_1 == 0 || num_2 == 0) {
                return 0;
            }
            if((num_1 > (2147483647 / num_2)) || ((-2147483648 / num_2) > num_1)) {
                errorProcessing(); //エラー
            } else {
                result = num_1 * num_2;
            }
        } else {
            //除算
            if(num_2 == 0) {
                errorProcessing(); //エラー
            } else {
                result = num_1 / num_2;
            }
        }

        return result;
    }

    //計算式を画面に表示する
    private void formulaDisplay(String operatorStr) {
        TextView input_message = findViewById(R.id.input_message);
        String input_messageStr = "";
        String addNumber = Integer.toString(firstNum);

        if(secondOperator == 0) {
            input_messageStr = Integer.toString(firstNum) + " " + operatorStr + " ";
            addNumber = Integer.toString(secondNum);
        } else {
            input_messageStr = Integer.toString(firstNum) + " " + toStringOperator(firstOperator) + " " +
                    Integer.toString(secondNum) + " " + operatorStr + " ";
            addNumber = Integer.toString(thirdNum);
        }

        //イコールボタンが押されていたら最後まで表示する
        if(isPushEqual) {
            input_messageStr += addNumber + " ＝";
        }

        input_message.setText(input_messageStr);
    }




    //イコールボタンが押されたとき
    View.OnClickListener Equal_Listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            TextView result_message = findViewById(R.id.result_message);

            if(result_message.getText().toString() == "ERROR") {
                result_message.setText("0");
            }
            String result_messageStr = result_message.getText().toString();

            if(isPushEqual) {
                //連続してイコールボタンが押された場合は直前に入力された数・演算子を使用する
                result_messageStr = resultDisplay(secondNum);
            } else {
                result_messageStr = resultDisplay(Integer.parseInt(result_messageStr));
            }

            //resultDisplay()の結果がエラーでなければ表示
            if(result_message.getText().toString() != "ERROR") {
                result_message.setText(result_messageStr);
            }
        }
    };

    //クリアボタンが押されたとき
    View.OnClickListener Clear_Listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            TextView result_message = findViewById(R.id.result_message);

            if(isPushEqual || (secondNum == 0)) {
                firstNum = 0;
                Clear();
            } else if(thirdNum == 0) {
                secondNum = 0;
                secondOperator = 0;
                formulaDisplay(toStringOperator(firstOperator));
            } else {
                thirdNum = 0;
                formulaDisplay(toStringOperator(secondOperator));
            }
            isPushoppo = false;

            result_message.setText("0");
        }
    };

    //イコールボタンを押されたときの計算結果を返す
    private String resultDisplay(int result_messageNumber) {
        String result_messageStr = "";
        int tempNum = 0;

        if(isPushEqual) {
            //連続してイコールボタンが押された場合
            thirdNum = 0;
            secondOperator = 0;
        }
        isPushEqual = true;

        if(secondOperator == 0) {
            if(firstOperator != 0) {
                secondNum = result_messageNumber;
                formulaDisplay(toStringOperator(firstOperator));
                firstNum = calculation(firstNum, secondNum, firstOperator);
            }
        } else {
            thirdNum = result_messageNumber;
            formulaDisplay(toStringOperator(secondOperator));
            tempNum = calculation(secondNum, thirdNum, secondOperator);
            firstNum = calculation(firstNum, tempNum, firstOperator);

            //連続してイコールボタンが押された場合に備えて
            //直前の入力をsecondNum, firstOperatorに統一しておく
            secondNum = thirdNum;
            firstOperator = secondOperator;
        }

        result_messageStr = Integer.toString(firstNum);

        return result_messageStr;
    }






}
