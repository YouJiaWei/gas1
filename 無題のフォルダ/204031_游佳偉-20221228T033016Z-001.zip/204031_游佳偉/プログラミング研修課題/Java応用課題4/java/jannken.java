package com.systena.yuuk;


import android.app.AlertDialog;
import android.view.View;
import android.widget.ImageButton;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import android.content.Context;
import android.widget.Toast;





public class jannken extends MainActivity {

    public int win = 0;
    public int lose = 0;
    public int draw = 0;
    public String name = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jannken);

        Intent intent = new Intent(getApplication(),jannken_result.class);
        Intent intent1 = getIntent();


        ImageButton button_gu = findViewById(R.id.button_gu);
        ImageButton button_cho = findViewById(R.id.button_cho);
        ImageButton button_pa= findViewById(R.id.button_pa);
        //Button button44= findViewById(R.id.button44);



        TextView name_1 = findViewById(R.id.name_1);
        TextView jannken_data= findViewById(R.id.jannken_data);


        Bundle extras = intent1.getExtras();
        //データを取る
        if (extras != null){
            name_1.setText(extras.getString("MyName"));
            win = extras.getInt("Win");
            lose = extras.getInt("Lose");
            draw = extras.getInt("Draw");
        }else{
            name_1.setText("");
        }

        //勝敗履歴
        String data = "手を選択してください\n\n勝敗履歴：\n"
                + win + "勝\n" + lose + "敗\n" + draw + "引き分け";
        jannken_data.setText(data);



        /*button44.setOnClickListener(v -> {
            name = myName.getText().toString();
            if(isNameAcceped(name)) {
                setScreenJankenResult(0);
            }
        });*/

        //ボタン グー
        button_gu.setOnClickListener(v -> {
            //Intent intent = new Intent(getApplication(), jannken_result.class);
            //startActivity(intent);
            name = name_1.getText().toString();
                intent.putExtra("MyName",name);
                intent.putExtra("MyHand",0);
                intent.putExtra("Win",win);
                intent.putExtra("Lose",lose);
                intent.putExtra("Draw",draw);

            if (name.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setMessage("名前を設定してください")
                        .setPositiveButton("OK", null)
                        .show();
            }else {
                if(name.length()>20){
                    new AlertDialog.Builder(this)
                            .setMessage("名前を20文字以内にしてください")
                            .setPositiveButton("OK", null)
                            .show();
                    }else {
                        startActivity(intent);
                    }
                }
        });
        //ボタン cyo
        button_cho.setOnClickListener(v -> {
                name = name_1.getText().toString();
                intent.putExtra("MyName",name);
                intent.putExtra("MyHand",1);
                intent.putExtra("Win",win);
                intent.putExtra("Lose",lose);
                intent.putExtra("Draw",draw);
            if (name.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setMessage("名前を設定してください")
                        .setPositiveButton("OK", null)
                        .show();
            }else {
                if(name.length()>20){
                    new AlertDialog.Builder(this)
                            .setMessage("名前を20文字以内にしてください")
                            .setPositiveButton("OK", null)
                            .show();
                    }else {
                        startActivity(intent);
                    }
                }
            }

        );
        //ボタン pa
        button_pa.setOnClickListener(v -> {
            name = name_1.getText().toString();
            intent.putExtra("MyName",name);
            intent.putExtra("MyHand",2);
            intent.putExtra("Win",win);
            intent.putExtra("Lose",lose);
            intent.putExtra("Draw",draw);
            if (name.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setMessage("名前を設定してください")
                        .setPositiveButton("OK", null)
                        .show();
            }else {
                if(name.length()>20){
                    new AlertDialog.Builder(this)
                            .setMessage("名前を20文字以内にしてください")
                            .setPositiveButton("OK", null)
                            .show();

                }else {
                    startActivity(intent);
                }
            }
        });


    }





}

