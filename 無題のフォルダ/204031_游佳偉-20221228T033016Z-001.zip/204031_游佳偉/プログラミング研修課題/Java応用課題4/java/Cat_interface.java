package com.systena.yuuk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Cat_interface extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat_interface);

        //インスタンス生成
        CatExt catExt = new CatExt("ミミ", "ニャ", 60, 100);
        CatExt other = new CatExt("ミミ", "ニャ", 50, 90);


        //ボタン定義
        Button button_introduce = (Button) findViewById(R.id.button_introduce);
        Button button_call = (Button) findViewById(R.id.button_call);
        Button button_eat = (Button) findViewById(R.id.button_eat);
        Button button_tired = (Button) findViewById(R.id.button_tired);
        Button button_hotel = (Button) findViewById(R.id.button_hotel);
        Button button_jannken = (Button) findViewById(R.id.button_jannken);
        Button button_work = (Button) findViewById(R.id.button_work);
        Button button_fight = (Button) findViewById(R.id.button_fight);


        //テキスト定義
        EditText hotel_message = (EditText) findViewById(R.id.hotel_message);
        EditText call_message = (EditText) findViewById(R.id.call_message);
        TextView result_cat = (TextView) findViewById(R.id.result_cat);


        //自己紹介
        button_introduce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                result = catExt.showMe();
                result_cat.setText(result);
            }
        });


        button_call.setOnClickListener(v -> {
            String result = "";
            String songStr=call_message.getText().toString();
            int i = 0;
            if (songStr.length() != 0) {
                i = Integer.parseInt(songStr);
            }
            result = catExt.sing(i);
            result_cat.setText(result);
        });


        //ホテルに泊まる
        button_hotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                String hotelStr=hotel_message.getText().toString();
                int i = 0;
                if (hotelStr.length() != 0) {
                    i = Integer.parseInt(hotelStr);
                }
                result = catExt.hotel(i);
                result_cat.setText(result);
            }
        });

        //食べる
        button_eat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                result = catExt.eat();
                result_cat.setText(result);
            }
        });

        //疲れてる?
        button_tired.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                if (catExt.tired()) {
                    result = "疲れたニャ";
                } else {
                    result = "元気だニャ";
                }
                result_cat.setText(result);
            }
        });


        //じゃんけん
        button_jannken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                result = catExt.janken();
                result_cat.setText(result);
            }
        });

        //働く
        button_work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                result = catExt.work();
                result_cat.setText(result);
            }
        });

        //ケンカ
        button_fight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = "";
                result = catExt.fight(other);
                result_cat.setText(result);


            }
        });



    }
}
