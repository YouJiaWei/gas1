package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //String result = callSubject03_1(6);
        //String result = callSubject03_2(2);
        //String result = callSubject03_3(30);
        //String result = callSubject03_4(10);
        //String result = callSubject03_5(10);
        //String result = callSubject03_6(5);
        //String result = callSubject03_7(9);
        //String result = callSubject03_8(-5);
        //String result = callSubject03_9(10);
        //String result = callSubject03_10(30);
        //String result = callSubject03_11(5);
        //String result = callSubject03_12(5);
        //String result = callSubject03_13(5);
        String result = callSubject03_14(5);

        TextView tvResult = findViewById(R.id.tv_result);
        tvResult.setText(result);
    }

    private String callSubject03_1(final int a){
        String resultStr= "";
        for(int i=0;i<=a;i=i+2){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }

    private String callSubject03_2(final int a){
        String resultStr= "";
        for(int i=5;i>=a;i=i-1){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }

    private String callSubject03_3(final int a){
        String resultStr= "";
        for(int i=-10;i<=a;i=i+5){
            resultStr= resultStr+i+"\n";
        }
        return resultStr;
    }

    private String callSubject03_4(final int a){
        String resultStr= "";
        for(int i=1;i<=a;i=i+1){
            resultStr= resultStr+(i*i)+"\n";
        }
        return resultStr;
    }

    private String callSubject03_5(final int a){
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            resultStr = resultStr + i +" "+  (10-i) + "\n";
        }
        return resultStr;
    }

    private String callSubject03_6(final int a){
        int n=1;
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            n=n+i;
            resultStr = resultStr + n + "\n";
        }
        return resultStr;
    }

    private String callSubject03_7(final int a){
        int n=1;
        int k=0;
        String resultStr= "";
        for(int i=0;i<=a;i=i+1) {
            n=n+k;
            resultStr = resultStr + n + "\n";
            k=n-k;
        }
        return resultStr;
    }

    private String callSubject03_8(final int a){
        int n=0;
        String resultStr= "";
        for(int i=1;i<=a;i=i+1) {
            n=n+i;
        }
        resultStr = resultStr +"1から" +a+"までの合計は"+n + "\n";
        return resultStr;
    }

    private String callSubject03_9(final int a){
        int n=0;
        int i;
        String resultStr= "";
        if(a>0){
            for(i=1;i<a;i=i+1) {
                n=n+i;
                resultStr = resultStr +i+"+";
            }
            n=n+i;
            resultStr = resultStr +i+"="+n;
        }
        else{
            resultStr = resultStr +"?";
        }

        return resultStr;
    }

    private String callSubject03_10(final int a){
        long n=1;
        int i;
        String resultStr= "";
            for(i=1;i<=a;i=i+1) {
                resultStr = resultStr +i+"回目は"+n+"円\n";
                n=n*2;
            }

        return resultStr;
    }

    private String callSubject03_11(final int a){
        int i;
        int j;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            for(j=0;j<a;j++) {
                resultStr = resultStr + "＊";
            }
            resultStr = resultStr +"\n";
        }
        //resultStr = resultStr +"\n";
        return resultStr;
    }

    private String callSubject03_12(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            if(i%2==0) {
                for (j = 0; j < 5; j++) {
                    resultStr = resultStr + "＊";
                }
            }else{
                for (k = 0; k < 5; k = k + 1) {
                    resultStr = resultStr + "＋";
                }
            }
            resultStr = resultStr +"\n";
        }
        return resultStr;
    }

    private String callSubject03_13(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
                for (j = 0; j < i+1; j++) {
                    resultStr = resultStr + "＊";
                }
            resultStr = resultStr +"\n";
            }
        return resultStr;
    }

    private String callSubject03_14(final int a){
        int i;
        int j;
        int k;
        String resultStr= "";
        for(i=0;i<a;i=i+1) {
            for (j = 5; j > i; j--) {
                resultStr = resultStr + "＊";
            }
            resultStr = resultStr +"\n";
        }
        return resultStr;
    }

}