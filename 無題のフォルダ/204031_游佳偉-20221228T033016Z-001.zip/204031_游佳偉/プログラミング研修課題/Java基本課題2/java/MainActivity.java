package com.systena.yuuk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //String result = callSubject02_1(20);
        //String result = callSubject02_2(15);
        //String result = callSubject02_3(90);
        //String result = callSubject02_4(12);
        //String result = callSubject02_5(11);
        //String result = callSubject02_6(30);
        //String result = callSubject02_7(15);
        //String result = callSubject02_8(70);
        //String result = callSubject02_9(10);
        String result = callSubject02_10(10);
        TextView tvResult = findViewById(R.id.tv_result);
        tvResult.setText(result);
    }
    private String callSubject02_1(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>=18){
            resultStr= resultStr+"どうぞ\n";
        }
            resultStr = resultStr+"おしまい";
        return resultStr;
    }

    private String callSubject02_2(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>=18){
            resultStr= resultStr
                    +"どうぞ\n";
        }
        else{
            resultStr = resultStr
                    +"お断り\n";
        }
        resultStr = resultStr+"おしまい";
        return resultStr;
    }

    private String callSubject02_3(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age<18){
            resultStr = resultStr
                    +"お断り\n";
        }
        else if(age>=18 && age<80){
            resultStr= resultStr
                    +"どうぞ\n";
        }
        else if(age>=80){
            resultStr = resultStr
                    +"どうぞどうぞ\n";
        }
        resultStr = resultStr+"おしまい";
        return resultStr;
    }

    private String callSubject02_4(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a%3==0 && a%5==0){
            resultStr = resultStr
                    +a+"は3でも5でも割り切れます。\n";
        }

        return resultStr;
    }

    private String callSubject02_5(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a%3==0 || a%5==0){
            resultStr = resultStr
                    +a+"は、3か5で割り切れます。\n";
        }
        else{
            resultStr = resultStr
                    +a+"は、3でも5でも割り切れません。\n";
        }

        return resultStr;
    }

    private String callSubject02_6(final int a){
        String resultStr= "2桁の整数値は"+a+"\n";
        if(a/10==3 || a%10==3){
            resultStr = resultStr
                    +a+"に3が含まれます。\n";
        }
        else{
            resultStr = resultStr
                    +a+"に3は含まれません。\n";
        }

        return resultStr;
    }

    private String callSubject02_7(final int a){
        String resultStr= "2桁の整数値は"+a+"\n";
        if(a/10==3 || a%10==3 || a%3==0){
            resultStr = resultStr
                    +a+" ナベアツ ";
            }
        if(a%5==0){
            resultStr = resultStr
                    +" 犬";
        }

        return resultStr;
    }

    private String callSubject02_8(final int age){
        String resultStr= "年齢は"+age+"歳\n";
        if(age>12 && age<70){
            resultStr = resultStr
                    +"1000円";
        }
        else{
            resultStr = resultStr
                    +"ただ";
        }

        return resultStr;
    }

    private String callSubject02_9(final int a){
        String resultStr= "整数値は"+a+"\n";
        if(a==7){
            resultStr = resultStr
                    +"ハッピー";
        }
        else if(a==3){
            resultStr = resultStr
                    +"ラッキー";
        }
        else if(a==13){
            resultStr = resultStr
                    +"アンラッキー";
        }
        else{
            resultStr = resultStr
                    +"普通";
        }

        return resultStr;
    }

    private String callSubject02_10(final int a){
        String resultStr= "整数値は"+a+"\n";
        switch (a){
            case 7:
            resultStr = resultStr
                    +"ハッピー";
            break;
            case 3:
            resultStr = resultStr
                    +"ラッキー";
            break;
            case 13:
            resultStr = resultStr
                    +"アンラッキー";
            break;
            default:
            resultStr = resultStr
                    +"普通";
        }

        return resultStr;
    }

}
